using System;
using System.IO;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;

namespace XNACS1Lib
{
    internal  class TextureTable : ResourceTable
    {
        private ContentManager m_ContentManager;        // GraphicsSystem should allocate this
        private List<Texture2D> m_Texture;

        override protected String FolderName { get { return @"Textures"; } }
        override protected String ResourceFileExtension { get { return @".xnb"; } }

        public TextureTable(ContentManager manager)
        {
            m_ContentManager = manager;
            m_Texture = new List<Texture2D>();
        }

        public void LoadTexture(String name)
        {
            String useName = FindResourceFile(name);
            if (null != useName)
                m_Texture.Add( m_ContentManager.Load<Texture2D>(useName) );
        }

        public Texture2D FindTexture(String name)
        {
            int index = FindResourceIndex(name);
            Texture2D foundTex = null;

            if (index >= 0)
                foundTex = m_Texture[index];

            return foundTex;
        }
    }
}