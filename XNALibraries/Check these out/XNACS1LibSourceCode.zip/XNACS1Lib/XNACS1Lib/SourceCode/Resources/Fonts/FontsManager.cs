using System;
using System.IO;
//using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
//using Microsoft.Xna.Framework.Input;
// using Microsoft.Xna.Framework.Content;

namespace XNACS1Lib
{
    /// <summary>
    /// This is the base class for programming assignments.
    /// </summary>
    internal class FontManager
    {      
        private const float InitFontSpace = 10.0f;
        private const float FontHeight = 16.0f;
        private const float FontWidth = 10.5f;
        private float BottomFontY;

        private SpriteFont m_LabelFont=null, m_EchoFont=null;
        private float m_SpaceFillerWidth;
        private XNACS1LibDrawHelper m_DrawHelper = null;
        private Color m_LabelColor, m_TopEchoColor, m_BottomEchoColor;

        public FontManager(GraphicsDevice graphicsDevice, Microsoft.Xna.Framework.Content.ContentManager content, int appWinHeight)
        {
            m_LabelColor = Color.Red;
            m_TopEchoColor = Color.Black;
            m_BottomEchoColor = Color.Black;
            ComputeFontPositions(appWinHeight);

            m_LabelFont = null;
            m_EchoFont = null;
            m_DrawHelper = null;

            const String path1 = @"Resources/Fonts/Arial";
            const String path2 = @"Content/Resources/Fonts/Arial";
            String usePath = null;

#if WINDOWS_PHONE
            usePath = path2;
#else
            if (File.Exists(string.Concat(path1, ".xnb")))
                usePath = path1;
            else if (File.Exists(string.Concat(path2, ".xnb")))
                usePath = path2;
#endif

            if (null!=usePath) {
                m_LabelFont = content.Load<SpriteFont>(usePath);
                m_EchoFont = content.Load<SpriteFont>(usePath);
                Vector2 spaceSize = m_EchoFont.MeasureString(" ");
                m_SpaceFillerWidth = spaceSize.X;
            }
        }

        public void ComputeFontPositions(int h)
        {
            BottomFontY = h - 25.0f;
        }

        public void SetDrawHelper(XNACS1LibDrawHelper d) { m_DrawHelper = d; }

        public Color TopEchoFontColor
        {
            set { m_TopEchoColor = value; }
        }

        public Color BottomEchoFontColor
        {
            set { m_BottomEchoColor = value; }
        }

        
        public void DrawFonts(String top, String bottom)
        {
            if (null != m_LabelFont)
            {
                // m_DrawFont.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred, SaveStateMode.SaveState);
                if (null != top)
                {
                    m_DrawHelper.DrawFont(m_LabelFont, @"Status:", new Vector2(InitFontSpace, 0.0f), m_LabelColor);
                    m_DrawHelper.DrawFont(m_EchoFont, top, new Vector2(InitFontSpace + (FontWidth * 7.0f), 0.0f), m_TopEchoColor);
                }

                if (null != bottom)
                {
                    m_DrawHelper.DrawFont(m_LabelFont, @"Status:", new Vector2(InitFontSpace, BottomFontY), m_LabelColor);
                    m_DrawHelper.DrawFont(m_EchoFont, bottom, new Vector2(InitFontSpace + (FontWidth * 7.0f), BottomFontY), m_BottomEchoColor);
                }
                // m_DrawFont.End();
            }
        }

        public void DrawFontsAt(Vector2 dcAt, String msg, Color c)
        {
            if ( (null != m_LabelFont) && (null != msg) )
            {
                // m_DrawFont.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.Deferred, SaveStateMode.SaveState);
                    Vector2 fontAt = dcAt;
                    String [] lines = msg.Split(new Char[] {'\n'});
                    Vector2[] msgSize = new Vector2[lines.Length];
                    float totalHeight = 0;
                    float maxWidth = 0;
                    int l = 0;
                    foreach (String s in lines) {
                        msgSize[l] = m_EchoFont.MeasureString(s);
                        if (msgSize[l].X > maxWidth)
                            maxWidth = msgSize[l].X;
                        totalHeight += msgSize[l].Y;
                        l++;
                    }
                    fontAt.Y -= (totalHeight/2.0f);
                    fontAt.X -= (maxWidth / 2.0f);
                    //
                    // Try to align center ...
                    // 
                    msg = "";
                    for (l = 0; l < lines.Length; l++)
                    {
                        int n = (int) ((0.5f*(maxWidth - msgSize[l].X)) / m_SpaceFillerWidth);
                        for (int i = 0; i < n; i++)
                            msg += " ";
                        msg += lines[l];
                        msg += "\n";
                    }
                    m_DrawHelper.DrawFont(m_EchoFont, msg, fontAt, c);
                // m_DrawFont.End();
            }
        }
    }
}