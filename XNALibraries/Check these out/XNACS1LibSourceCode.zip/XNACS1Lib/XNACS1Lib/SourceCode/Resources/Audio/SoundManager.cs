#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
#endregion

namespace XNACS1Lib
{

    /// <summary>
    /// Abstracts away the sounds for a simple interface using the Sounds enum
    /// </summary>
    internal class SoundManager : ResourceTable
    {

        private ContentManager mContentManager = null;
        private List<SoundEffect> mAudioClips;
        private SoundEffectInstance mBgAudio =null;

        override protected String FolderName { get { return @"Audio"; } }
        override protected String ResourceFileExtension { get { return @".xnb"; } }

        public SoundManager(ContentManager m)
        {
            mContentManager = m;
            mBgAudio = null;
            mAudioClips = new List<SoundEffect>();
        }

        private int LoadAudioClip(String name)
        {
            int index = -1;
            String useName = FindResourceFile(name);
            if (null != useName)
            {
                mAudioClips.Add(mContentManager.Load<SoundEffect>(useName));
                index = mAudioClips.Count - 1;
            }
            return index;
        }

        private SoundEffect FindAudioClip(String name)
        {
            int index = FindResourceIndex(name);
            if (index < 0)
                index = LoadAudioClip(name);

            SoundEffect foundClip = null;

            if (index >= 0)
                foundClip = mAudioClips[index];

            return foundClip;
        }
        /// <summary>
        /// Playas the sound with name for lengthInSec
        /// </summary>
        /// <param name="name"></param>
        public void PlaySound(String name)
        {
            SoundEffect s = FindAudioClip(name);
            if (null != s)
            {
                s.Play();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="level"></param>
        public void PlayBackgroundAudio(String name, float level)
        {
            if (null == name)
            {
                if (null != mBgAudio)
                {
                    mBgAudio.Stop(true);
                    mBgAudio.Dispose();
                }
                mBgAudio = null;
            }
            else
            {
                SoundEffect bg = FindAudioClip(name);
                if (null != bg)
                {
                    bg.Play(0.1f, 0f, 0f);
                    if (null != mBgAudio)
                    {
                        mBgAudio.Stop(true);
                        mBgAudio.Dispose();
                    }
                    mBgAudio = bg.CreateInstance();
                    mBgAudio.IsLooped = true;
                    mBgAudio.Volume = level;
                    mBgAudio.Play();

                    SoundEffect t = FindAudioClip(name);
                    //t.Play();
                }
            }
        }
    }
}