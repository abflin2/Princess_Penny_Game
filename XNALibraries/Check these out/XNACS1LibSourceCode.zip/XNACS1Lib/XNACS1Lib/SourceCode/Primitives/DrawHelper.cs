//*******************************************
// PredefinedEmitter.cs
// Author:
// ChangeLog:
// Samuel Cook and Ron Cook - Created a set for particles/emitters, a set to track primitives
//      with shouldtravel set to true, rather than running travelprimitive() on every primitive.
//      Changed the parameters of some draw methods to take different parameters.
//      Added support for Texture based collision (currently not working)
//      Added functionality in the draw methods so that additive blending could be supported. 
//      Added support so that the circle and rectangle were created on the fly rather than requiring two texture files.
//*******************************************

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace XNACS1Lib
{
    /// <summary>
    /// This is the base class for programming assignments.
    /// </summary>
    internal class XNACS1LibDrawHelper
    {
        private TextureTable m_TexTable;
        private FontManager m_FontManager;
        private Vector2 m_WorldMin, m_WorldMax;
        private Vector2 m_DeviceSize;

        private Matrix mW2D;

        private GraphicsDevice m_GraphicsDevice = null;
        private SpriteBatch mSpriteBatch = null;
        // internal SpriteBlendMode m_CurrentBlendMode;
        internal BlendState m_CurrentBlendState = BlendState.AlphaBlend;

        private Texture2D m_TheCircle = null;
        private Texture2D m_TheSquare = null;

        private List<XNACS1Primitive> m_DrawSet = null;
        private List<XNACS1Primitive> m_TravelSet = null;
        private List<XNACS1ParticleEmitter> m_EmitterSet = null;

        public XNACS1LibDrawHelper(GraphicsDevice graphicsDevice, ContentManager c, XNACS1Rectangle worldBound, FontManager fontManager, Vector2 deviceSize)
        {
            m_DrawSet = new List<XNACS1Primitive>();
            m_TravelSet = new List<XNACS1Primitive>();
            m_EmitterSet = new List<XNACS1ParticleEmitter>();
            
            m_GraphicsDevice = graphicsDevice;

            mSpriteBatch = new SpriteBatch(m_GraphicsDevice);

            //
            SetTransformationMatrices(worldBound, deviceSize);

            m_TexTable = new TextureTable(c);
            m_FontManager = fontManager;
            fontManager.SetDrawHelper(this);

            int CircleSize = 256;
            Texture2D Circle = new Texture2D(graphicsDevice, CircleSize, CircleSize);
            Color[] CircleData = new Color[CircleSize * CircleSize];
            for (int x = 0; x < CircleSize; x++)
                for (int y = 0; y < CircleSize; y++) {
                    if (Math.Sqrt(Math.Pow(x - CircleSize / 2, 2) + Math.Pow(y - CircleSize / 2, 2)) > CircleSize/2) {
                        int off = x + CircleSize * y;
                        CircleData[off] = Color.Black;
                        CircleData[off].A = 0x00;
                        
                    } else
                        CircleData[x + CircleSize * y] = Color.White;
                    }
            Circle.SetData<Color>(CircleData);

            Texture2D Square = new Texture2D(graphicsDevice, 1, 1);
            Color[] SquareData = new Color[1];
            SquareData[0] = Color.White;
            Square.SetData<Color>(SquareData);

            m_TheCircle = Circle;
            m_TheSquare = Square;
        }

        public void SetTransformationMatrices(XNACS1Rectangle worldBound, Vector2 deviceSize)
        {

            Vector2 wMin = worldBound.MinBound;
            Vector2 wMax = worldBound.MaxBound;

            Vector2 size = wMax - wMin;
            Matrix toOrg, toDC;
            toOrg = Matrix.CreateTranslation(-wMin.X, -wMin.Y, 0.0f);
            toDC = Matrix.CreateScale(deviceSize.X / size.X, deviceSize.Y / size.Y, 1.0f);
            mW2D = toOrg * toDC;
            
            m_WorldMin = wMin;
            m_WorldMax = wMax;
            m_DeviceSize = deviceSize;
        }


        public Texture2D FindTexture(String name)
        {
            Texture2D tex = null;
            if (null != name)
            {
                tex = m_TexTable.FindTexture(name);
                if (tex == null)
                {
                    m_TexTable.LoadTexture(name);
                    tex = m_TexTable.FindTexture(name);
                }
            }
            return tex;
        }

        public Texture2D FindTexture(XNACS1Primitive primitive) {
            Texture2D tex = null;
            if (null != primitive.Texture) {
                tex = m_TexTable.FindTexture(primitive.Texture);
                if (tex == null) {
                    m_TexTable.LoadTexture(primitive.Texture);
                    tex = m_TexTable.FindTexture(primitive.Texture);
                }
            }

            if (tex == null) {
                if (primitive.m_Type == XNACS1Primitive.PrimitiveType.PrimitiveCircle)
                    tex = m_TheCircle;
                else
                    tex = m_TheSquare;
            }

            return tex;
        }

        internal bool TexturesCollided(XNACS1Primitive primitive1, XNACS1Primitive primitive2) {
            Texture2D tex1 = FindTexture(primitive1);
            Texture2D tex2 = FindTexture(primitive2);
            Color[] tex1Data = new Color[tex1.Width*tex1.Height];
            tex1.GetData<Color>(tex1Data);
            Color[] tex2Data= new Color[tex2.Width*tex2.Height];
            tex1.GetData<Color>(tex2Data);

            Vector2 wMin = m_WorldMin;
            Vector2 wMax = m_WorldMax;
            Vector2 wSize = wMax - wMin;
            Vector3 deviceSize = new Vector3(m_DeviceSize,1);

            Vector3 center = new Vector3();
            Vector3 scale = new Vector3();
            scale.Z = 1;
            center.Z = 0;


            
            //center = Vector3.Transform(center, mW2D);

            scale.X = primitive1.SizeX/((float) tex1.Width);
            scale.Y = primitive1.SizeY/((float) tex1.Height);

            center.X = primitive1.Center.X - primitive1.SizeX / 2f;
            center.Y = primitive1.Center.Y - primitive1.SizeY / 2f;


            Matrix m1 = Matrix.CreateScale(scale) *
                Matrix.CreateRotationZ(primitive2.RotateAngle * (float)Math.PI / 180) *
                Matrix.CreateTranslation(center) * mW2D
                ;


            //center = Vector3.Transform(center, mW2D);

            scale.X = primitive2.SizeX/((float)tex2.Width);
            scale.Y = primitive2.SizeY/((float)tex2.Height);


            center.X = primitive2.Center.X - primitive2.SizeX/2f;
            center.Y = primitive2.Center.Y - primitive2.SizeY/ 2f;

            Matrix m2 = Matrix.CreateScale(scale) * 
                Matrix.CreateRotationZ(primitive2.RotateAngle * (float)Math.PI / 180)*
                Matrix.CreateTranslation(center) * mW2D
                ;


            return IntersectPixels(m1,tex1.Width,tex1.Height,tex1Data,m2,tex2.Width,tex2.Height,tex2Data);

        }


        /// <summary>
        /// Determines if there is overlap of the non-transparent pixels between two
        /// sprites.
        /// </summary>
        /// <param name="transformA">World transform of the first sprite.</param>
        /// <param name="widthA">Width of the first sprite's texture.</param>
        /// <param name="heightA">Height of the first sprite's texture.</param>
        /// <param name="dataA">Pixel color data of the first sprite.</param>
        /// <param name="transformB">World transform of the second sprite.</param>
        /// <param name="widthB">Width of the second sprite's texture.</param>
        /// <param name="heightB">Height of the second sprite's texture.</param>
        /// <param name="dataB">Pixel color data of the second sprite.</param>
        /// <returns>True if non-transparent pixels overlap; false otherwise</returns>
        private static bool IntersectPixels(
                            Matrix transformA, int widthA, int heightA, Color[] dataA,
                            Matrix transformB, int widthB, int heightB, Color[] dataB) {
            // Calculate a matrix which transforms from A's local space into
            // world space and then into B's local space
            Matrix transformAToB = transformA * Matrix.Invert(transformB);

            // When a point moves in A's local space, it moves in B's local space with a
            // fixed direction and distance proportional to the movement in A.
            // This algorithm steps through A one pixel at a time along A's X and Y axes
            // Calculate the analogous steps in B:
            Vector2 stepX = Vector2.TransformNormal(Vector2.UnitX, transformAToB);
            Vector2 stepY = Vector2.TransformNormal(Vector2.UnitY, transformAToB);

            // Calculate the top left corner of A in B's local space
            // This variable will be reused to keep track of the start of each row
            Vector2 yPosInB = Vector2.Transform(Vector2.Zero, transformAToB);

            // For each row of pixels in A
            for (int yA = 0; yA < heightA; yA++) {
                // Start at the beginning of the row
                Vector2 posInB = yPosInB;

                // For each pixel in this row
                for (int xA = 0; xA < widthA; xA++) {
                    // Round to the nearest pixel
                    int xB = (int)Math.Round(posInB.X);
                    int yB = (int)Math.Round(posInB.Y);

                    // If the pixel lies within the bounds of B
                    if (0 <= xB && xB < widthB &&
                        0 <= yB && yB < heightB) {
                        // Get the colors of the overlapping pixels
                        Color colorA = dataA[xA + yA * widthA];
                        Color colorB = dataB[xB + yB * widthB];

                        // If both pixels are not completely transparent,
                        if (colorA.A != 0 && colorB.A != 0) {
                            // then an intersection has been found
                            return true;
                        }
                    }

                    // Move to the next pixel in the row
                    posInB += stepX;
                }

                // Move to the next row
                yPosInB += stepY;
            }

            // No intersection found
            return false;
        }



        //private Matrix ComputeXform(Vector2 scale, float rotateInDegree, Vector2 translate, Vector2 pivot) {
        //    Matrix pm, tm, sm, rm;
        //    pm = Matrix.CreateTranslation(-pivot.X, -pivot.Y, 0.0f);
        //    tm = Matrix.CreateTranslation(translate.X + pivot.X, translate.Y + pivot.Y, 0.0f);
        //    rm = Matrix.CreateRotationZ((float)(rotateInDegree * (Math.PI / 180.0f)));
        //    sm = Matrix.CreateScale(scale.X, scale.Y, 1.0f);
        //    return pm * sm * rm * tm;
        //}

        //private void XformVertices(Matrix m, VertexPositionColorTexture[] input, VertexPositionColorTexture[] output)
        //{
        //    for (int i = 0; i < input.Length; i++)
        //    {
        //        // output[i] = input[i];
        //        output[i].Position = Vector3.Transform(input[i].Position, m);
        //        output[i].Position = Vector3.Transform(output[i].Position, mW2D);
        //        output[i].Position.Y = m_DeviceSize.Y - output[i].Position.Y;   // drawing origin is top/left
        //    }
        //}

        private Rectangle World2Device(Vector3 tl, float w, float h)
        {
            Vector3 br = new Vector3(tl.X + w, tl.Y - h, 0f);
            tl = Vector3.Transform(tl, mW2D);
            br = Vector3.Transform(br, mW2D);
            w = br.X - tl.X;
            h = tl.Y - br.Y;

            Rectangle r;

                tl.Y = m_DeviceSize.Y - tl.Y;
                r = new Rectangle((int)(tl.X+0.5f), (int)(tl.Y+0.5f), (int)(w+0.5f), (int)(h+0.5f));

            return r;
        }

        /// <summary>
        /// Compute the top-left position given that XNA sprite rotation is always top-left.
        /// Our rotation is always on the middle of geometry:
        /// 
        /// desiredRotationCenterX + px = topLeft.X, 
        /// desiredRotationCenterY + py = topLeft.Y. 
        /// 
        /// </summary>
        private Vector3 ComputeTopLeft(Vector3 tl, float px, float py, float r)
        {
            double xS = px * Math.Sin(r);
            double xC = px * Math.Cos(r);
            double yS = py * Math.Sin(r);
            double yC = py * Math.Cos(r);
            return new Vector3(tl.X - px + (float)(xC - yS), 
                               tl.Y - py + (float)(xS + yC),
                               0f);
        }

        /// <summary>
        /// Actually draws the primitive onto screen.
        /// </summary>
        /// <param name="dcRec">The dcRec to draw</param>
        /// <param name="texName">Texture name</param>
        /// <param name="useTex">if texName is null, use this texture instead (TheCircle or TheSquare)</param>
        /// <param name="color">color to draw in in the absence of texName</param>
        /// <param name="rotation">to rotate</param>
        /// <param name="sourceRect">Specifies the portion of texture to be drawn</param>
        private void DrawDCRectangle(Rectangle dcRec, Rectangle? sourceRect, String texName, Texture2D useTex, Color color, float rotation) {
            Texture2D tex = FindTexture(texName);
            Color useColor = color;

            if (null == tex) {
                tex = useTex;
            }

            mSpriteBatch.Draw(tex, dcRec, sourceRect, useColor, -rotation, Vector2.Zero, SpriteEffects.None,0);

        }


        /// <summary>
        /// Draws a circle.
        /// </summary>
        /// <param name="center">Center of the circle.</param>
        /// <param name="radius">Radius of the circle.</param>
        /// <param name="rotation">Rotation of the circle (about the center, in degree).</param>
        /// <param name="color">Color of the circle.</param>
        /// <param name="texName">Name of texture (use null for none) for the circle.</param>
        /// <param name="sourceRect">Specifies what region of the texture to draw</param>
        public void DrawCircle(Vector2 center, float radius, Rectangle? sourceRect, float rotation, Color color, String texName) {
            Vector3 topLeft = new Vector3(center.X - radius, center.Y + radius, 0f);

            // convert rotation to radian
            rotation = MathHelper.ToRadians(rotation);

            // desiredRotationCenterX + px = topLeft.X 
            // desiredRotationCenterY + py = topLeft.Y
            topLeft = ComputeTopLeft(topLeft, -radius, radius, rotation);

            float width = 2f * radius;
            Rectangle dcRec = World2Device(topLeft, width, width);

            DrawDCRectangle(dcRec, sourceRect, texName, m_TheCircle, color, rotation);
        }

        /// <summary>
        /// Draws a rotated rectangle.
        /// </summary>
        /// <param name="center">Center of the rectangle.</param>
        /// <param name="xWidthDest">Horizontal width of the rectangle.</param>
        /// <param name="yHeightDest">Vertical height of the rectangle.</param>
        /// <param name="rot">Rotation in degrees.</param>
        /// <param name="color">Color of the rectangle.</param>
        /// <param name="texName">Name of texture (use null for none) for the rectangle.</param>
        ///<param name="sourceRect">Specifies the portion of the texture to be drawn.</param>
        public void DrawRectangle(Vector2 center, float xWidthDest, float yHeightDest, Rectangle? sourceRect, float rot, Color color, String texName) {
            Vector3 topLeft = new Vector3(center.X - (xWidthDest / 2f), center.Y + (yHeightDest / 2f), 0f);

            // convert rotation to rad
            rot = MathHelper.ToRadians(rot);

            // desiredRotationCenterX + px = topLeft.X 
            // desiredRotationCenterY + py = topLeft.Y
            topLeft = ComputeTopLeft(topLeft, -xWidthDest / 2f, yHeightDest / 2f, rot);

            Rectangle dcRec = World2Device(topLeft, xWidthDest, yHeightDest);
            DrawDCRectangle(dcRec, sourceRect, texName, m_TheSquare, color, rot);
        }

        
        public void DrawLineSegments(Vector2 a, Vector2 b)
        {
            //VertexPositionColorTexture[] v = new VertexPositionColorTexture[2];
            //VertexPositionColorTexture[] vo = new VertexPositionColorTexture[2];
            //v[0] = new VertexPositionColorTexture(
            //            new Vector3(a.X, a.Y, 0.0f), Color.White, new Vector2(0.0f, 0.0f));
            //v[1] = new VertexPositionColorTexture(
            //            new Vector3(b.X, b.Y, 0.0f), Color.White, new Vector2(1.0f, 1.0f));
            //Matrix m = ComputeXform(new Vector2(1.0f, 1.0f), 0.0f, new Vector2(0.0f, 0.0f), new Vector2(0.0f, 0.0f));
            //XformVertices(m, v, vo);
            //m_GraphicsDevice.DrawUserPrimitives(PrimitiveType.LineList, vo, 0, 1);
        }

        public void BeginDraw(BlendState blendState)
        {
            m_CurrentBlendState = blendState;
            // mSpriteBatch.Begin(blendMode, SpriteSortMode.Immediate, SaveStateMode.None);
            mSpriteBatch.Begin(SpriteSortMode.Immediate, blendState);
        }

        public void EndDraw()
        {
            mSpriteBatch.End();
        }

        public void SetBlendMode(BlendState blendState)
        {
            if (m_CurrentBlendState != blendState)
            {
                EndDraw();
                BeginDraw(blendState);
            }
        }

        private Vector2 WCToDC(Vector2 wc)
        {
            Vector2 dc = new Vector2();
            Vector2 wcSize = m_WorldMax - m_WorldMin;
            dc.X = (wc.X - m_WorldMin.X) * m_DeviceSize.X / wcSize.X;
            dc.Y = ((wc.Y - m_WorldMin.Y) * m_DeviceSize.Y / wcSize.Y);
            dc.Y = m_DeviceSize.Y - dc.Y;
            return dc;
        }

        public void DrawFontAt(Vector2 wcAt, String msg, Color c)
        {
            m_FontManager.DrawFontsAt(WCToDC(wcAt), msg, c);
        }

        public void DrawFont(SpriteFont font, string msg, Vector2 at, Color c)
        {
            SetBlendMode(BlendState.AlphaBlend);
            mSpriteBatch.DrawString(font, msg, at, c);
        }

        #region draw set support
        public void AddToSet(XNACS1Primitive p) {
            if (null != m_DrawSet) {
                if (!m_DrawSet.Contains(p)) {
                    m_DrawSet.Add(p);
                }
                if (p.ShouldTravel || p.UseSpriteSheetAnimation)
                    if (!m_TravelSet.Contains(p))
                        m_TravelSet.Add(p);
            }
        }
        internal void UpdateTravelSet(XNACS1Primitive p) {
            if (null != m_TravelSet) {
                if (p.ShouldTravel || p.UseSpriteSheetAnimation) {
                    if (!m_TravelSet.Contains(p)) {
                        m_TravelSet.Add(p);
                    }
                }
                else {
                    m_TravelSet.Remove(p);
                }
            }
        }


        public void RemoveFromSet(XNACS1Primitive p) {
            if (null != m_DrawSet) {
                m_DrawSet.Remove(p);
                m_TravelSet.Remove(p);
            }
        }

        public void RemoveAllFromSet()
        {
            if (null != m_DrawSet) {
                m_DrawSet.Clear();
                m_TravelSet.Clear();
            }
        }

        public void TopOfDrawSet(XNACS1Primitive p)
        {
            if (null != m_DrawSet)
            {
                if (IsInDrawSet(p))
                {
                    m_DrawSet.Remove(p);
                    m_DrawSet.Add(p);
                }
            }
        }

        public void DrawAll()
        {
            if (null != m_DrawSet) {
                XNACS1Primitive p;
                for (int i = 0; i < m_DrawSet.Count; i++) {
                    p = m_DrawSet[i];
                    p.Draw();
                }
            }

        }

        public void TravelAll()
        {
            foreach(XNACS1ParticleEmitter emitter in m_EmitterSet) {
                emitter.CallUpdate();
            }

            foreach(XNACS1Primitive p in m_TravelSet) {
                p.TravelPrimitive();
                p.UpdateSpriteSheetAnimation();
            }

        }

        public bool IsInDrawSet(XNACS1Primitive p) {
            return m_DrawSet.Contains(p);
        }

        public int DrawSetSize()
        {
            return m_DrawSet.Count;
        }
        #endregion draw set support


        internal void AddEmitter(XNACS1ParticleEmitter emitter) {
            m_EmitterSet.Add(emitter);
        }
        internal void RemoveEmitter(XNACS1ParticleEmitter emitter) {
            m_EmitterSet.Remove(emitter);
        }
    }
}